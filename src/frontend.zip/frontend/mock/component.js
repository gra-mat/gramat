import { css, html, LitElement } from "../../lib/lit.min.js";

class LearnMock extends LitElement {
  static properties = {
  };

  static styles = css``;

  constructor() {
    super();
  }

  render() {
    return html`
    learn to fly
    <x-link to=''>home</x-link>
    <x-link to='learn'>learn</x-link>
    <x-link to='account'>account</x-link>
    <x-link to='settings'>settings</x-link>
    `;
  }
}

customElements.define("x-learn-view", LearnMock);

class Account extends LitElement {
  static properties = {
  };

  static styles = css``;

  constructor() {
    super();
  }

  render() {
    return html`
    accountability
    <x-link to=''>home</x-link>
    <x-link to='learn'>learn</x-link>
    <x-link to='account'>account</x-link>
    <x-link to='settings'>settings</x-link>
    `;
  }
}

customElements.define("x-account-view", Account);

class SettingsMock extends LitElement {
  static properties = {
  };

  static styles = css``;

  constructor() {
    super();
  }

  render() {
    return html`
    setting up someone
    <x-link to=''>home</x-link>
    <x-link to='learn'>learn</x-link>
    <x-link to='account'>account</x-link>
    <x-link to='settings'>settings</x-link>
    `;
  }
}

customElements.define("x-settings-view", SettingsMock);