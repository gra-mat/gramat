import { store } from "../store.js";

const mock_user = {
    "id": 1,
    "name": "admin",
    "email": "admin@gramat.com",
    "authProvider": "local",
    "avatarUrl": null,
    "permissions": "all",
    "points": 0,
    "strengths": [],
    "weaknesses": [],
    "suggestedExercises": [],
}

store.set('user', mock_user);